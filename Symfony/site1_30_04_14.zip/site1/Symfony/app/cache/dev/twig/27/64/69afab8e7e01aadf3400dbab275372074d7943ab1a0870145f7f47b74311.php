<?php

/* SonataUserBundle:Form:form_admin_fields.html.twig */
class __TwigTemplate_276469afab8e7e01aadf3400dbab275372074d7943ab1a0870145f7f47b74311 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'sonata_security_roles_widget' => array($this, 'block_sonata_security_roles_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->displayBlock('sonata_security_roles_widget', $context, $blocks);
    }

    public function block_sonata_security_roles_widget($context, array $blocks = array())
    {
        // line 2
        ob_start();
        // line 3
        echo "    <div class=\"editable\">
        <h4>";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("field.label_roles_editable", array(), "SonataUserBundle"), "html", null, true);
        echo "</h4>
        ";
        // line 5
        $this->displayBlock("choice_widget", $context, $blocks);
        echo "
    </div>
    ";
        // line 7
        if ((twig_length_filter($this->env, (isset($context["read_only_choices"]) ? $context["read_only_choices"] : $this->getContext($context, "read_only_choices"))) > 0)) {
            // line 8
            echo "    <div class=\"readonly\">
        <h4>";
            // line 9
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("field.label_roles_readonly", array(), "SonataUserBundle"), "html", null, true);
            echo "</h4>
        <ul>
        ";
            // line 11
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["read_only_choices"]) ? $context["read_only_choices"] : $this->getContext($context, "read_only_choices")));
            foreach ($context['_seq'] as $context["_key"] => $context["choice"]) {
                // line 12
                echo "            <li>";
                echo twig_escape_filter($this->env, (isset($context["choice"]) ? $context["choice"] : $this->getContext($context, "choice")), "html", null, true);
                echo "</li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['choice'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 14
            echo "        </ul>
    </div>
    ";
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    public function getTemplateName()
    {
        return "SonataUserBundle:Form:form_admin_fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  54 => 12,  19 => 11,  270 => 4,  268 => 3,  264 => 2,  253 => 1,  243 => 83,  233 => 81,  221 => 79,  212 => 74,  210 => 73,  208 => 72,  206 => 71,  202 => 68,  198 => 66,  196 => 65,  192 => 64,  189 => 61,  187 => 60,  185 => 59,  182 => 57,  180 => 56,  177 => 54,  175 => 53,  172 => 51,  169 => 49,  167 => 48,  165 => 47,  163 => 45,  160 => 44,  156 => 41,  154 => 40,  137 => 37,  120 => 36,  115 => 33,  113 => 31,  111 => 30,  108 => 28,  100 => 23,  95 => 22,  90 => 20,  81 => 15,  65 => 83,  50 => 11,  47 => 43,  45 => 9,  42 => 8,  40 => 7,  37 => 19,  35 => 5,  30 => 9,  129 => 59,  117 => 34,  109 => 53,  107 => 52,  105 => 51,  103 => 50,  101 => 49,  97 => 47,  93 => 21,  89 => 43,  86 => 17,  84 => 16,  77 => 36,  62 => 82,  55 => 79,  36 => 15,  34 => 15,  27 => 8,  25 => 12,  20 => 1,  98 => 34,  91 => 44,  82 => 39,  75 => 17,  72 => 10,  69 => 9,  66 => 29,  63 => 14,  60 => 81,  53 => 35,  51 => 34,  48 => 33,  46 => 32,  39 => 17,  31 => 4,  28 => 3,  26 => 2,  23 => 12,  88 => 26,  79 => 37,  74 => 11,  70 => 30,  64 => 28,  59 => 24,  57 => 80,  52 => 78,  49 => 20,  44 => 18,  41 => 29,  32 => 14,  29 => 15,);
    }
}
