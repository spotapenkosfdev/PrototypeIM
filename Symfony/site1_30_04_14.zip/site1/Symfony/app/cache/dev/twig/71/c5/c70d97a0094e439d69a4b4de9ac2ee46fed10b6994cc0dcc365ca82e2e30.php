<?php

/* SonataAdminBundle:Button:show_button.html.twig */
class __TwigTemplate_71c5c70d97a0094e439d69a4b4de9ac2ee46fed10b6994cc0dcc365ca82e2e30 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 11
        echo "
";
        // line 12
        if (((($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "hasroute", array(0 => "show"), "method") && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "id", array(0 => (isset($context["object"]) ? $context["object"] : $this->getContext($context, "object"))), "method")) && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "isGranted", array(0 => "VIEW", 1 => (isset($context["object"]) ? $context["object"] : $this->getContext($context, "object"))), "method")) && (twig_length_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "show")) > 0))) {
            // line 13
            echo "    <a class=\"sonata-action-element\" href=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "generateObjectUrl", array(0 => "show", 1 => (isset($context["object"]) ? $context["object"] : $this->getContext($context, "object"))), "method"), "html", null, true);
            echo "\">
        <i class=\"fa fa-eye\"></i>
        ";
            // line 15
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("link_action_show", array(), "SonataAdminBundle"), "html", null, true);
            echo "</a>
";
        }
    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:Button:show_button.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 12,  19 => 11,  777 => 235,  771 => 232,  768 => 231,  766 => 230,  762 => 228,  759 => 227,  747 => 226,  744 => 225,  741 => 224,  738 => 223,  735 => 222,  733 => 221,  728 => 219,  716 => 217,  713 => 216,  710 => 215,  702 => 210,  699 => 209,  682 => 207,  665 => 206,  660 => 204,  655 => 203,  652 => 202,  649 => 201,  643 => 197,  639 => 195,  637 => 194,  632 => 193,  615 => 191,  598 => 190,  594 => 189,  589 => 188,  586 => 187,  583 => 186,  580 => 185,  577 => 184,  575 => 183,  572 => 182,  563 => 177,  559 => 175,  557 => 174,  554 => 173,  552 => 172,  549 => 171,  545 => 150,  539 => 148,  533 => 146,  530 => 145,  527 => 144,  520 => 166,  514 => 164,  512 => 163,  509 => 162,  503 => 159,  500 => 158,  498 => 157,  495 => 156,  492 => 155,  474 => 153,  472 => 152,  469 => 151,  467 => 144,  458 => 143,  453 => 140,  447 => 137,  444 => 136,  441 => 135,  438 => 134,  432 => 133,  428 => 132,  421 => 131,  419 => 130,  416 => 129,  413 => 128,  410 => 127,  407 => 126,  404 => 125,  401 => 124,  398 => 123,  395 => 122,  392 => 121,  389 => 120,  379 => 114,  376 => 113,  373 => 112,  367 => 110,  365 => 109,  360 => 108,  357 => 107,  354 => 106,  350 => 104,  347 => 102,  344 => 100,  342 => 99,  339 => 98,  337 => 97,  329 => 96,  325 => 94,  308 => 89,  299 => 86,  294 => 85,  291 => 84,  286 => 82,  267 => 74,  260 => 72,  255 => 71,  250 => 69,  245 => 66,  208 => 57,  204 => 55,  198 => 53,  195 => 51,  193 => 50,  177 => 49,  172 => 46,  169 => 44,  166 => 42,  164 => 41,  159 => 39,  143 => 38,  135 => 35,  130 => 33,  127 => 32,  124 => 31,  121 => 30,  118 => 29,  115 => 28,  107 => 25,  101 => 23,  89 => 18,  83 => 16,  66 => 214,  64 => 201,  61 => 200,  56 => 181,  49 => 120,  44 => 82,  39 => 69,  34 => 61,  31 => 60,  29 => 12,  309 => 148,  301 => 144,  295 => 142,  289 => 83,  283 => 138,  277 => 136,  274 => 135,  272 => 134,  269 => 133,  265 => 130,  248 => 116,  242 => 113,  236 => 109,  230 => 106,  224 => 103,  219 => 101,  216 => 100,  203 => 93,  197 => 90,  192 => 88,  187 => 87,  185 => 86,  182 => 85,  176 => 82,  170 => 79,  165 => 77,  158 => 75,  153 => 72,  147 => 69,  144 => 68,  141 => 37,  138 => 36,  136 => 60,  132 => 34,  128 => 58,  123 => 57,  120 => 56,  80 => 41,  75 => 39,  72 => 37,  70 => 33,  67 => 32,  35 => 16,  330 => 103,  327 => 154,  321 => 152,  315 => 91,  312 => 90,  306 => 88,  303 => 87,  300 => 93,  292 => 91,  290 => 90,  287 => 89,  280 => 78,  275 => 86,  273 => 85,  270 => 75,  264 => 73,  262 => 81,  256 => 79,  253 => 70,  247 => 75,  243 => 73,  240 => 65,  237 => 71,  231 => 69,  225 => 64,  222 => 66,  220 => 63,  217 => 62,  214 => 61,  209 => 96,  206 => 57,  202 => 55,  194 => 52,  190 => 49,  184 => 48,  178 => 46,  175 => 45,  171 => 44,  168 => 43,  162 => 41,  160 => 76,  156 => 38,  150 => 34,  142 => 30,  137 => 29,  134 => 28,  129 => 25,  126 => 24,  119 => 108,  112 => 27,  105 => 61,  102 => 60,  100 => 57,  97 => 56,  95 => 20,  92 => 19,  87 => 23,  76 => 13,  73 => 12,  69 => 215,  62 => 29,  59 => 182,  55 => 12,  52 => 11,  46 => 119,  43 => 20,  41 => 81,  38 => 17,  36 => 68,  30 => 15,  24 => 13,  116 => 107,  113 => 39,  110 => 26,  104 => 24,  98 => 21,  94 => 30,  90 => 24,  86 => 17,  81 => 15,  78 => 14,  71 => 23,  68 => 22,  60 => 18,  54 => 171,  51 => 170,  48 => 14,  12 => 36,);
    }
}
