<?php

/* SonataBlockBundle:Block:block_core_menu.html.twig */
class __TwigTemplate_6edcad620c561d32f97d4d9953964f5ee333ca062980b0e365fc3a12f0c030c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'block' => array($this, 'block_block'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute($this->getAttribute((isset($context["sonata_block"]) ? $context["sonata_block"] : $this->getContext($context, "sonata_block")), "templates"), "block_base"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 14
    public function block_block($context, array $blocks = array())
    {
        // line 15
        echo "    ";
        echo $this->env->getExtension('knp_menu')->render((isset($context["menu"]) ? $context["menu"] : $this->getContext($context, "menu")), (isset($context["menu_options"]) ? $context["menu_options"] : $this->getContext($context, "menu_options")));
        echo "
";
    }

    public function getTemplateName()
    {
        return "SonataBlockBundle:Block:block_core_menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 34,  91 => 27,  82 => 21,  75 => 17,  72 => 16,  69 => 15,  66 => 14,  63 => 13,  60 => 12,  53 => 35,  51 => 34,  48 => 33,  46 => 32,  39 => 26,  31 => 21,  28 => 20,  26 => 14,  23 => 11,  88 => 26,  79 => 33,  74 => 31,  70 => 30,  64 => 27,  59 => 24,  57 => 23,  52 => 21,  49 => 20,  44 => 19,  41 => 29,  32 => 15,  29 => 15,);
    }
}
