<?php

/* SonataBlockBundle:Block:block_core_text.html.twig */
class __TwigTemplate_22fceba436ba3a8adea4cc164dfffb98fd5560b215875faee55d529b3dcbff4e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'block' => array($this, 'block_block'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute($this->getAttribute((isset($context["sonata_block"]) ? $context["sonata_block"] : $this->getContext($context, "sonata_block")), "templates"), "block_base"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 14
    public function block_block($context, array $blocks = array())
    {
        // line 15
        echo "    ";
        echo $this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "content");
        echo "
";
    }

    public function getTemplateName()
    {
        return "SonataBlockBundle:Block:block_core_text.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 15,  26 => 14,  154 => 49,  148 => 48,  142 => 46,  139 => 45,  135 => 44,  127 => 43,  124 => 42,  120 => 40,  114 => 39,  108 => 37,  105 => 36,  101 => 35,  98 => 34,  96 => 33,  92 => 31,  86 => 30,  80 => 28,  77 => 27,  73 => 26,  65 => 25,  62 => 24,  56 => 23,  53 => 22,  50 => 21,  47 => 20,  42 => 19,  40 => 18,  36 => 16,  31 => 15,  28 => 14,);
    }
}
