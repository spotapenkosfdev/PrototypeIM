<?php

/* SonataAdminBundle:CRUD:base_list_field.html.twig */
class __TwigTemplate_50a783b587c24190e80d17ab5c3593fd27e7d5e469a72244aef013747ca17076 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'field' => array($this, 'block_field'),
            'field_span_attributes' => array($this, 'block_field_span_attributes'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 11
        echo "
<td class=\"sonata-ba-list-field sonata-ba-list-field-";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "type"), "html", null, true);
        echo "\" objectId=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "id", array(0 => (isset($context["object"]) ? $context["object"] : $this->getContext($context, "object"))), "method"), "html", null, true);
        echo "\">
    ";
        // line 13
        if (((($this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : null), "options", array(), "any", false, true), "identifier", array(), "any", true, true) && $this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : null), "options", array(), "any", false, true), "route", array(), "any", true, true)) && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "isGranted", array(0 => ((($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "options"), "route"), "name") == "show")) ? ("VIEW") : (twig_upper_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "options"), "route"), "name")))), 1 => (isset($context["object"]) ? $context["object"] : $this->getContext($context, "object"))), "method")) && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "hasRoute", array(0 => $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "options"), "route"), "name")), "method"))) {
            // line 19
            echo "        <a class=\"sonata-link-identifier\" href=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "generateObjectUrl", array(0 => $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "options"), "route"), "name"), 1 => (isset($context["object"]) ? $context["object"] : $this->getContext($context, "object")), 2 => $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "options"), "route"), "parameters")), "method"), "html", null, true);
            echo "\">";
            // line 20
            $this->displayBlock('field', $context, $blocks);
            // line 21
            echo "</a>
    ";
        } else {
            // line 23
            echo "        ";
            $context["isEditable"] = (($this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : null), "options", array(), "any", false, true), "editable", array(), "any", true, true) && $this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "options"), "editable")) && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "isGranted", array(0 => "EDIT", 1 => (isset($context["object"]) ? $context["object"] : $this->getContext($context, "object"))), "method"));
            // line 24
            echo "        ";
            $context["xEditableType"] = $this->env->getExtension('sonata_admin')->getXEditableType($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "type"));
            // line 25
            echo "
        ";
            // line 26
            if (((isset($context["isEditable"]) ? $context["isEditable"] : $this->getContext($context, "isEditable")) && (isset($context["xEditableType"]) ? $context["xEditableType"] : $this->getContext($context, "xEditableType")))) {
                // line 27
                echo "            ";
                $context["url"] = $this->env->getExtension('routing')->getPath("sonata_admin_set_object_field_value", array("context" => "list", "field" => $this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "name"), "objectId" => $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "id", array(0 => (isset($context["object"]) ? $context["object"] : $this->getContext($context, "object"))), "method"), "code" => $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "code", array(0 => (isset($context["object"]) ? $context["object"] : $this->getContext($context, "object"))), "method")));
                // line 28
                echo "            <span ";
                $this->displayBlock('field_span_attributes', $context, $blocks);
                echo ">
                ";
                // line 29
                $this->displayBlock("field", $context, $blocks);
                echo "
            </span>
        ";
            } else {
                // line 32
                echo "            ";
                $this->displayBlock("field", $context, $blocks);
                echo "
        ";
            }
            // line 34
            echo "    ";
        }
        // line 35
        echo "</td>
";
    }

    // line 20
    public function block_field($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, (isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), "html", null, true);
    }

    // line 28
    public function block_field_span_attributes($context, array $blocks = array())
    {
        echo "class=\"x-editable\" data-type=\"";
        echo twig_escape_filter($this->env, (isset($context["xEditableType"]) ? $context["xEditableType"] : $this->getContext($context, "xEditableType")), "html", null, true);
        echo "\" data-value=\"";
        echo twig_escape_filter($this->env, (isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), "html", null, true);
        echo "\" data-title=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "label"), array(), $this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "translationDomain")), "html", null, true);
        echo "\" data-pk=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "id", array(0 => (isset($context["object"]) ? $context["object"] : $this->getContext($context, "object"))), "method"), "html", null, true);
        echo "\" data-url=\"";
        echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : $this->getContext($context, "url")), "html", null, true);
        echo "\" ";
    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:base_list_field.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  624 => 224,  599 => 215,  594 => 212,  580 => 207,  577 => 206,  566 => 203,  563 => 202,  559 => 201,  545 => 198,  536 => 194,  526 => 190,  523 => 189,  518 => 180,  514 => 167,  507 => 165,  463 => 117,  415 => 127,  410 => 113,  406 => 111,  404 => 90,  376 => 153,  333 => 132,  329 => 130,  326 => 129,  318 => 86,  307 => 82,  287 => 77,  261 => 73,  280 => 87,  249 => 77,  218 => 65,  195 => 54,  12 => 36,  713 => 213,  704 => 209,  702 => 208,  698 => 206,  685 => 204,  668 => 200,  665 => 199,  634 => 190,  612 => 220,  607 => 218,  604 => 185,  601 => 216,  595 => 180,  591 => 178,  589 => 177,  584 => 176,  567 => 174,  538 => 170,  532 => 192,  504 => 164,  497 => 156,  491 => 131,  482 => 128,  472 => 149,  466 => 147,  455 => 115,  452 => 141,  401 => 89,  392 => 117,  382 => 115,  359 => 144,  353 => 104,  345 => 101,  340 => 136,  330 => 96,  324 => 92,  286 => 80,  205 => 56,  178 => 48,  118 => 46,  321 => 152,  295 => 83,  274 => 77,  272 => 134,  242 => 113,  236 => 71,  216 => 100,  70 => 27,  1414 => 421,  1408 => 419,  1402 => 417,  1400 => 416,  1398 => 415,  1394 => 414,  1385 => 413,  1383 => 412,  1380 => 411,  1367 => 405,  1361 => 403,  1355 => 401,  1353 => 400,  1351 => 399,  1347 => 398,  1341 => 397,  1339 => 396,  1336 => 395,  1323 => 389,  1317 => 387,  1311 => 385,  1309 => 384,  1307 => 383,  1303 => 382,  1297 => 381,  1291 => 380,  1287 => 379,  1283 => 378,  1279 => 377,  1273 => 376,  1271 => 375,  1268 => 374,  1256 => 369,  1251 => 368,  1249 => 367,  1246 => 366,  1237 => 360,  1231 => 358,  1228 => 357,  1223 => 356,  1221 => 355,  1218 => 354,  1211 => 349,  1202 => 347,  1198 => 346,  1195 => 345,  1192 => 344,  1190 => 343,  1187 => 342,  1179 => 338,  1177 => 337,  1174 => 336,  1168 => 332,  1162 => 330,  1159 => 329,  1157 => 328,  1154 => 327,  1145 => 322,  1143 => 321,  1118 => 320,  1115 => 319,  1112 => 318,  1109 => 317,  1106 => 316,  1103 => 315,  1100 => 314,  1098 => 313,  1095 => 312,  1088 => 308,  1084 => 307,  1079 => 306,  1077 => 305,  1074 => 304,  1067 => 299,  1064 => 298,  1056 => 293,  1053 => 292,  1051 => 291,  1048 => 290,  1040 => 285,  1036 => 284,  1032 => 283,  1029 => 282,  1027 => 281,  1024 => 280,  1016 => 276,  1014 => 272,  1012 => 271,  1009 => 270,  1004 => 266,  982 => 261,  979 => 260,  976 => 259,  973 => 258,  970 => 257,  967 => 256,  964 => 255,  961 => 254,  958 => 253,  955 => 252,  952 => 251,  950 => 250,  947 => 249,  939 => 243,  936 => 242,  934 => 241,  931 => 240,  923 => 236,  920 => 235,  918 => 234,  915 => 233,  903 => 229,  900 => 228,  897 => 227,  894 => 226,  892 => 225,  889 => 224,  881 => 220,  878 => 219,  876 => 218,  873 => 217,  865 => 213,  862 => 212,  860 => 211,  857 => 210,  849 => 206,  846 => 205,  844 => 204,  841 => 203,  833 => 199,  830 => 198,  828 => 197,  825 => 196,  817 => 192,  814 => 191,  812 => 190,  809 => 189,  801 => 185,  798 => 184,  796 => 183,  793 => 182,  785 => 178,  783 => 177,  780 => 176,  772 => 172,  769 => 171,  767 => 170,  764 => 169,  756 => 165,  753 => 164,  751 => 163,  749 => 162,  746 => 161,  739 => 156,  729 => 155,  724 => 154,  721 => 153,  715 => 151,  712 => 150,  710 => 149,  707 => 210,  699 => 142,  697 => 141,  696 => 140,  695 => 205,  694 => 138,  689 => 137,  683 => 135,  680 => 202,  675 => 132,  666 => 126,  662 => 198,  658 => 124,  654 => 193,  649 => 122,  643 => 120,  638 => 118,  635 => 226,  619 => 113,  617 => 189,  614 => 111,  598 => 107,  596 => 106,  593 => 105,  576 => 101,  557 => 96,  555 => 200,  547 => 93,  529 => 191,  527 => 166,  515 => 160,  512 => 84,  509 => 157,  503 => 81,  501 => 163,  493 => 155,  478 => 74,  470 => 121,  467 => 72,  464 => 146,  456 => 68,  450 => 114,  442 => 62,  433 => 60,  428 => 136,  426 => 135,  405 => 49,  400 => 47,  390 => 43,  385 => 159,  377 => 37,  371 => 35,  366 => 33,  363 => 32,  350 => 26,  344 => 24,  335 => 133,  332 => 20,  316 => 16,  290 => 5,  276 => 395,  266 => 83,  263 => 82,  245 => 335,  207 => 58,  194 => 53,  76 => 35,  200 => 54,  58 => 22,  170 => 55,  551 => 199,  548 => 183,  546 => 172,  541 => 171,  537 => 178,  525 => 172,  520 => 170,  516 => 169,  513 => 168,  506 => 156,  502 => 164,  496 => 79,  489 => 157,  483 => 154,  479 => 127,  475 => 152,  462 => 146,  448 => 139,  443 => 137,  424 => 91,  421 => 90,  414 => 52,  403 => 48,  399 => 116,  391 => 163,  386 => 116,  375 => 114,  372 => 113,  354 => 142,  348 => 100,  346 => 99,  342 => 23,  325 => 93,  313 => 84,  308 => 96,  302 => 79,  296 => 92,  292 => 82,  255 => 79,  184 => 47,  155 => 39,  146 => 47,  126 => 179,  124 => 47,  188 => 48,  181 => 232,  161 => 41,  320 => 87,  317 => 89,  311 => 14,  288 => 81,  284 => 76,  279 => 78,  275 => 103,  256 => 96,  250 => 67,  237 => 70,  232 => 84,  222 => 297,  191 => 246,  153 => 38,  150 => 56,  110 => 172,  687 => 397,  678 => 133,  673 => 388,  671 => 383,  661 => 380,  656 => 378,  651 => 192,  647 => 374,  640 => 119,  636 => 366,  630 => 363,  626 => 362,  620 => 223,  610 => 352,  602 => 347,  592 => 340,  585 => 209,  578 => 332,  574 => 205,  572 => 204,  570 => 326,  564 => 99,  560 => 322,  550 => 173,  543 => 181,  535 => 169,  531 => 175,  524 => 165,  519 => 295,  511 => 166,  505 => 291,  499 => 163,  495 => 289,  490 => 154,  485 => 124,  481 => 284,  477 => 283,  465 => 276,  459 => 116,  454 => 271,  447 => 113,  439 => 261,  429 => 254,  425 => 253,  418 => 248,  416 => 242,  412 => 126,  408 => 50,  397 => 235,  395 => 118,  388 => 42,  380 => 223,  369 => 148,  356 => 105,  339 => 191,  334 => 98,  310 => 83,  297 => 166,  291 => 165,  282 => 161,  259 => 149,  244 => 65,  231 => 133,  226 => 131,  215 => 64,  186 => 51,  152 => 36,  114 => 174,  104 => 34,  358 => 139,  351 => 141,  347 => 140,  343 => 132,  338 => 130,  327 => 94,  323 => 88,  319 => 90,  315 => 150,  301 => 144,  299 => 93,  293 => 91,  289 => 140,  281 => 75,  277 => 136,  271 => 76,  265 => 130,  262 => 105,  260 => 70,  257 => 80,  251 => 101,  248 => 116,  239 => 64,  228 => 68,  225 => 58,  213 => 63,  211 => 81,  197 => 54,  174 => 42,  148 => 64,  134 => 182,  127 => 26,  270 => 157,  253 => 342,  233 => 70,  212 => 60,  210 => 59,  206 => 71,  202 => 56,  198 => 55,  192 => 53,  185 => 86,  180 => 49,  175 => 47,  172 => 51,  167 => 48,  165 => 52,  160 => 39,  137 => 46,  113 => 39,  100 => 81,  90 => 34,  81 => 20,  65 => 30,  129 => 180,  97 => 33,  84 => 29,  34 => 15,  53 => 27,  77 => 30,  20 => 1,  23 => 18,  480 => 75,  474 => 122,  469 => 158,  461 => 145,  457 => 153,  453 => 151,  444 => 138,  440 => 148,  437 => 61,  435 => 146,  430 => 130,  427 => 129,  423 => 134,  413 => 134,  409 => 132,  407 => 123,  402 => 236,  398 => 88,  393 => 168,  387 => 122,  384 => 121,  381 => 157,  379 => 154,  374 => 36,  368 => 34,  365 => 141,  362 => 110,  360 => 109,  355 => 27,  341 => 131,  337 => 99,  322 => 91,  314 => 98,  312 => 149,  309 => 88,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 410,  268 => 84,  264 => 74,  258 => 72,  252 => 68,  247 => 66,  241 => 77,  229 => 73,  220 => 57,  214 => 99,  177 => 46,  169 => 44,  140 => 51,  132 => 42,  128 => 47,  107 => 38,  61 => 29,  273 => 85,  269 => 75,  254 => 147,  243 => 66,  240 => 73,  238 => 312,  235 => 63,  230 => 62,  227 => 301,  224 => 61,  221 => 67,  219 => 101,  217 => 56,  208 => 124,  204 => 57,  179 => 44,  159 => 51,  143 => 32,  135 => 28,  119 => 22,  102 => 37,  71 => 30,  67 => 32,  63 => 16,  59 => 27,  38 => 21,  94 => 30,  89 => 33,  85 => 32,  75 => 29,  68 => 24,  56 => 28,  87 => 28,  21 => 11,  26 => 14,  93 => 35,  88 => 26,  78 => 21,  46 => 8,  27 => 14,  44 => 18,  31 => 23,  28 => 22,  201 => 56,  196 => 52,  183 => 50,  171 => 44,  166 => 209,  163 => 40,  158 => 75,  156 => 38,  151 => 188,  142 => 61,  138 => 46,  136 => 58,  121 => 24,  117 => 175,  105 => 170,  91 => 37,  62 => 24,  49 => 18,  24 => 12,  25 => 12,  19 => 11,  79 => 35,  72 => 28,  69 => 27,  47 => 22,  40 => 24,  37 => 24,  22 => 11,  246 => 67,  157 => 56,  145 => 54,  139 => 59,  131 => 181,  123 => 48,  120 => 176,  115 => 45,  111 => 39,  108 => 171,  101 => 40,  98 => 72,  96 => 18,  83 => 22,  74 => 29,  66 => 17,  55 => 21,  52 => 22,  50 => 21,  43 => 25,  41 => 6,  35 => 16,  32 => 19,  29 => 3,  209 => 96,  203 => 55,  199 => 55,  193 => 51,  189 => 52,  187 => 50,  182 => 85,  176 => 82,  173 => 46,  168 => 43,  164 => 42,  162 => 68,  154 => 36,  149 => 35,  147 => 52,  144 => 26,  141 => 58,  133 => 49,  130 => 27,  125 => 42,  122 => 23,  116 => 40,  112 => 106,  109 => 105,  106 => 104,  103 => 82,  99 => 41,  95 => 71,  92 => 28,  86 => 25,  82 => 23,  80 => 31,  73 => 34,  64 => 25,  60 => 15,  57 => 14,  54 => 16,  51 => 26,  48 => 25,  45 => 24,  42 => 23,  39 => 14,  36 => 20,  33 => 16,  30 => 13,);
    }
}
