<?php

/* SonataDoctrineORMAdminBundle:CRUD:list_orm_many_to_one.html.twig */
class __TwigTemplate_7dc0a8b5e5f5ce5ff74cc0eb73c3ec7dedbd7c8d622c118faec509d032cace64 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "getTemplate", array(0 => "base_list_field"), "method"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 14
    public function block_field($context, array $blocks = array())
    {
        // line 15
        echo "    ";
        if ((isset($context["value"]) ? $context["value"] : $this->getContext($context, "value"))) {
            // line 16
            echo "        ";
            if ((($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "hasAssociationAdmin") && $this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "associationadmin"), "hasRoute", array(0 => "edit"), "method")) && $this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "associationadmin"), "isGranted", array(0 => "EDIT", 1 => (isset($context["value"]) ? $context["value"] : $this->getContext($context, "value"))), "method"))) {
                // line 17
                echo "            <a href=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "associationadmin"), "generateObjectUrl", array(0 => $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "options"), "route"), "name"), 1 => (isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), 2 => $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description")), "options"), "route"), "parameters")), "method"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('sonata_admin')->renderRelationElement((isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), (isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description"))), "html", null, true);
                echo "</a>
        ";
            } else {
                // line 19
                echo "            ";
                echo twig_escape_filter($this->env, $this->env->getExtension('sonata_admin')->renderRelationElement((isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), (isset($context["field_description"]) ? $context["field_description"] : $this->getContext($context, "field_description"))), "html", null, true);
                echo "
        ";
            }
            // line 21
            echo "    ";
        }
    }

    public function getTemplateName()
    {
        return "SonataDoctrineORMAdminBundle:CRUD:list_orm_many_to_one.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  170 => 74,  551 => 184,  548 => 183,  546 => 182,  541 => 180,  537 => 178,  525 => 172,  520 => 170,  516 => 169,  513 => 168,  506 => 166,  502 => 164,  496 => 161,  489 => 157,  483 => 154,  479 => 153,  475 => 152,  462 => 146,  448 => 139,  443 => 137,  424 => 128,  421 => 126,  414 => 122,  403 => 117,  399 => 116,  391 => 113,  386 => 111,  375 => 106,  372 => 105,  354 => 102,  348 => 100,  346 => 99,  342 => 97,  325 => 93,  313 => 90,  308 => 88,  302 => 84,  296 => 82,  292 => 81,  255 => 74,  184 => 64,  155 => 53,  146 => 49,  126 => 42,  124 => 31,  188 => 83,  181 => 80,  161 => 71,  320 => 122,  317 => 121,  311 => 118,  288 => 107,  284 => 106,  279 => 104,  275 => 103,  256 => 96,  250 => 93,  237 => 70,  232 => 84,  222 => 81,  191 => 69,  153 => 56,  150 => 65,  110 => 48,  687 => 397,  678 => 391,  673 => 388,  671 => 383,  661 => 380,  656 => 378,  651 => 376,  647 => 374,  640 => 367,  636 => 366,  630 => 363,  626 => 362,  620 => 359,  610 => 352,  602 => 347,  592 => 340,  585 => 336,  578 => 332,  574 => 330,  572 => 327,  570 => 326,  564 => 323,  560 => 322,  550 => 315,  543 => 181,  535 => 306,  531 => 175,  524 => 297,  519 => 295,  511 => 167,  505 => 291,  499 => 163,  495 => 289,  490 => 287,  485 => 285,  481 => 284,  477 => 283,  465 => 276,  459 => 273,  454 => 271,  447 => 266,  439 => 261,  429 => 254,  425 => 253,  418 => 248,  416 => 242,  412 => 241,  408 => 119,  397 => 235,  395 => 231,  388 => 112,  380 => 223,  369 => 215,  356 => 205,  339 => 191,  334 => 189,  310 => 89,  297 => 166,  291 => 165,  282 => 161,  259 => 149,  244 => 140,  231 => 133,  226 => 131,  215 => 78,  186 => 82,  152 => 92,  114 => 71,  104 => 67,  358 => 139,  351 => 135,  347 => 134,  343 => 132,  338 => 130,  327 => 126,  323 => 125,  319 => 92,  315 => 120,  301 => 117,  299 => 83,  293 => 109,  289 => 112,  281 => 105,  277 => 78,  271 => 108,  265 => 99,  262 => 105,  260 => 77,  257 => 103,  251 => 101,  248 => 100,  239 => 97,  228 => 68,  225 => 87,  213 => 82,  211 => 81,  197 => 70,  174 => 60,  148 => 64,  134 => 59,  127 => 32,  270 => 157,  253 => 95,  233 => 81,  212 => 74,  210 => 75,  206 => 71,  202 => 77,  198 => 66,  192 => 85,  185 => 68,  180 => 62,  175 => 77,  172 => 51,  167 => 48,  165 => 72,  160 => 70,  137 => 46,  113 => 41,  100 => 36,  90 => 20,  81 => 25,  65 => 30,  129 => 57,  97 => 63,  84 => 39,  34 => 16,  53 => 10,  77 => 58,  20 => 11,  23 => 18,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 134,  435 => 146,  430 => 130,  427 => 129,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 236,  398 => 129,  393 => 114,  387 => 122,  384 => 121,  381 => 108,  379 => 119,  374 => 116,  368 => 103,  365 => 141,  362 => 110,  360 => 109,  355 => 106,  341 => 131,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 117,  305 => 87,  298 => 91,  294 => 90,  285 => 111,  283 => 88,  278 => 160,  268 => 107,  264 => 2,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 80,  214 => 69,  177 => 61,  169 => 57,  140 => 55,  132 => 58,  128 => 49,  107 => 52,  61 => 25,  273 => 96,  269 => 100,  254 => 147,  243 => 89,  240 => 139,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 67,  219 => 84,  217 => 79,  208 => 124,  204 => 66,  179 => 66,  159 => 70,  143 => 48,  135 => 35,  119 => 28,  102 => 38,  71 => 19,  67 => 27,  63 => 15,  59 => 23,  38 => 17,  94 => 69,  89 => 40,  85 => 34,  75 => 17,  68 => 31,  56 => 24,  87 => 33,  21 => 12,  26 => 14,  93 => 34,  88 => 60,  78 => 24,  46 => 35,  27 => 8,  44 => 18,  31 => 15,  28 => 14,  201 => 65,  196 => 65,  183 => 82,  171 => 63,  166 => 100,  163 => 45,  158 => 62,  156 => 68,  151 => 63,  142 => 61,  138 => 36,  136 => 56,  121 => 53,  117 => 51,  105 => 27,  91 => 34,  62 => 29,  49 => 21,  24 => 13,  25 => 12,  19 => 11,  79 => 37,  72 => 10,  69 => 50,  47 => 19,  40 => 20,  37 => 19,  22 => 12,  246 => 99,  157 => 56,  145 => 52,  139 => 60,  131 => 48,  123 => 54,  120 => 36,  115 => 50,  111 => 78,  108 => 48,  101 => 49,  98 => 44,  96 => 31,  83 => 25,  74 => 34,  66 => 29,  55 => 22,  52 => 17,  50 => 20,  43 => 19,  41 => 18,  35 => 17,  32 => 16,  29 => 15,  209 => 82,  203 => 122,  199 => 67,  193 => 73,  189 => 71,  187 => 60,  182 => 80,  176 => 77,  173 => 65,  168 => 60,  164 => 72,  162 => 71,  154 => 67,  149 => 50,  147 => 90,  144 => 62,  141 => 48,  133 => 55,  130 => 57,  125 => 45,  122 => 44,  116 => 45,  112 => 49,  109 => 40,  106 => 36,  103 => 46,  99 => 26,  95 => 43,  92 => 61,  86 => 17,  82 => 33,  80 => 19,  73 => 29,  64 => 23,  60 => 22,  57 => 20,  54 => 18,  51 => 38,  48 => 40,  45 => 19,  42 => 18,  39 => 17,  36 => 16,  33 => 4,  30 => 15,);
    }
}
