<?php

/* SonataCoreBundle:FlashMessage:render.html.twig */
class __TwigTemplate_f6b7fecfb787bd18c5c7dab447f556da222b7e7a6394272332171341c9280cf7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('sonata_core_flashmessage')->getFlashMessagesTypes());
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 12
            echo "    ";
            $context["domain"] = ((array_key_exists("domain", $context)) ? ((isset($context["domain"]) ? $context["domain"] : $this->getContext($context, "domain"))) : (null));
            // line 13
            echo "    ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->env->getExtension('sonata_core_flashmessage')->getFlashMessages((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), (isset($context["domain"]) ? $context["domain"] : $this->getContext($context, "domain"))));
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 14
                echo "        <div class=\"alert alert-";
                echo twig_escape_filter($this->env, $this->env->getExtension('sonata_core_status')->statusClass((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"))), "html", null, true);
                echo "\">
            ";
                // line 15
                echo (isset($context["message"]) ? $context["message"] : $this->getContext($context, "message"));
                echo "
        </div>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "SonataCoreBundle:FlashMessage:render.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 14,  23 => 12,  19 => 11,  217 => 56,  203 => 55,  200 => 54,  196 => 52,  188 => 48,  183 => 46,  177 => 43,  143 => 33,  136 => 30,  129 => 27,  126 => 26,  124 => 25,  121 => 24,  118 => 23,  108 => 21,  96 => 18,  87 => 14,  71 => 11,  68 => 10,  36 => 15,  32 => 4,  27 => 13,  25 => 12,  20 => 1,  175 => 74,  168 => 41,  162 => 68,  156 => 64,  152 => 62,  144 => 59,  141 => 58,  134 => 55,  123 => 52,  120 => 51,  111 => 22,  101 => 42,  90 => 16,  81 => 33,  74 => 30,  43 => 18,  37 => 17,  29 => 3,  26 => 13,  911 => 264,  908 => 263,  905 => 262,  901 => 295,  897 => 293,  891 => 290,  888 => 289,  886 => 288,  880 => 285,  872 => 284,  869 => 283,  867 => 282,  864 => 281,  858 => 279,  856 => 278,  853 => 277,  847 => 275,  845 => 274,  842 => 273,  836 => 271,  834 => 270,  831 => 269,  825 => 267,  823 => 266,  820 => 265,  818 => 262,  815 => 261,  812 => 260,  808 => 254,  803 => 251,  795 => 246,  789 => 242,  787 => 241,  783 => 239,  777 => 237,  775 => 236,  771 => 234,  765 => 231,  762 => 230,  760 => 229,  757 => 228,  754 => 227,  751 => 226,  746 => 255,  743 => 226,  740 => 225,  735 => 296,  733 => 260,  728 => 257,  726 => 225,  723 => 224,  720 => 223,  715 => 298,  713 => 223,  710 => 222,  707 => 221,  702 => 214,  699 => 213,  695 => 212,  691 => 210,  685 => 209,  680 => 206,  674 => 205,  662 => 203,  659 => 202,  655 => 201,  648 => 200,  642 => 199,  639 => 198,  636 => 197,  633 => 196,  628 => 195,  626 => 194,  619 => 191,  615 => 190,  611 => 188,  609 => 187,  606 => 186,  603 => 185,  596 => 184,  593 => 183,  590 => 182,  587 => 181,  581 => 180,  578 => 179,  575 => 178,  572 => 176,  565 => 175,  562 => 174,  556 => 173,  553 => 172,  549 => 171,  546 => 170,  543 => 169,  540 => 168,  534 => 167,  530 => 165,  516 => 156,  510 => 154,  507 => 153,  504 => 152,  500 => 216,  497 => 213,  494 => 168,  492 => 167,  489 => 166,  486 => 152,  483 => 151,  477 => 217,  475 => 151,  471 => 149,  468 => 148,  460 => 137,  457 => 136,  449 => 130,  446 => 129,  438 => 123,  435 => 122,  431 => 119,  427 => 117,  421 => 115,  418 => 114,  415 => 113,  401 => 112,  395 => 110,  391 => 108,  385 => 106,  377 => 104,  375 => 103,  372 => 102,  369 => 101,  351 => 100,  348 => 99,  346 => 98,  343 => 97,  340 => 96,  337 => 95,  333 => 144,  329 => 142,  327 => 122,  323 => 120,  321 => 95,  310 => 86,  307 => 85,  304 => 84,  296 => 81,  291 => 79,  288 => 78,  282 => 76,  277 => 52,  268 => 50,  264 => 49,  257 => 45,  253 => 43,  247 => 42,  239 => 41,  235 => 39,  232 => 38,  227 => 35,  218 => 33,  214 => 32,  211 => 31,  208 => 30,  202 => 26,  199 => 25,  193 => 51,  186 => 47,  184 => 221,  181 => 220,  179 => 44,  174 => 42,  171 => 84,  169 => 78,  164 => 76,  160 => 38,  157 => 37,  154 => 36,  140 => 71,  132 => 28,  128 => 66,  122 => 64,  105 => 20,  102 => 19,  99 => 41,  93 => 17,  86 => 56,  82 => 54,  80 => 13,  77 => 12,  75 => 30,  72 => 29,  70 => 29,  65 => 23,  62 => 24,  60 => 21,  56 => 21,  54 => 18,  52 => 17,  50 => 16,  48 => 8,  46 => 19,  44 => 13,  40 => 11,  170 => 55,  165 => 52,  159 => 51,  153 => 49,  150 => 35,  146 => 34,  138 => 57,  135 => 69,  131 => 43,  125 => 65,  119 => 40,  116 => 50,  112 => 38,  109 => 46,  107 => 36,  103 => 34,  97 => 33,  91 => 58,  88 => 37,  84 => 29,  76 => 28,  73 => 27,  67 => 26,  64 => 25,  61 => 24,  58 => 22,  53 => 20,  51 => 9,  45 => 18,  42 => 7,  39 => 16,  34 => 16,  28 => 14,);
    }
}
