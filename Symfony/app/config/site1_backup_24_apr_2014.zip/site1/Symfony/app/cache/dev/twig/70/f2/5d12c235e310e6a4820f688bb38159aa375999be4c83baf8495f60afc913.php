<?php

/* SonataAdminBundle:Core:add_block.html.twig */
class __TwigTemplate_70f25d12c235e310e6a4820f688bb38159aa375999be4c83baf8495f60afc913 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'user_block' => array($this, 'block_user_block'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->displayBlock('user_block', $context, $blocks);
    }

    public function block_user_block($context, array $blocks = array())
    {
        // line 2
        echo "    ";
        $context["itemsPerColumn"] = $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "dropdown_number_groups_per_colums"), "method");
        // line 3
        echo "    ";
        $context["columnsCount"] = twig_round((twig_length_filter($this->env, $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "dashboardgroups")) / (isset($context["itemsPerColumn"]) ? $context["itemsPerColumn"] : $this->getContext($context, "itemsPerColumn"))));
        // line 4
        echo "

    <ul class=\"dropdown-menu";
        // line 6
        if (((isset($context["columnsCount"]) ? $context["columnsCount"] : $this->getContext($context, "columnsCount")) > 1)) {
            echo " multi-column";
        }
        echo " dropdown-add\"
        ";
        // line 7
        if (((isset($context["columnsCount"]) ? $context["columnsCount"] : $this->getContext($context, "columnsCount")) > 1)) {
            echo "style=\"width: ";
            echo twig_escape_filter($this->env, ((isset($context["columnsCount"]) ? $context["columnsCount"] : $this->getContext($context, "columnsCount")) * 140), "html", null, true);
            echo "px;\"";
        }
        // line 8
        echo "            >
        ";
        // line 9
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "dashboardgroups"));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 10
            echo "            ";
            $context["display"] = (twig_test_empty($this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "roles")) || $this->env->getExtension('security')->isGranted("ROLE_SUPER_ADMIN"));
            // line 11
            echo "            ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "roles"));
            foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
                if ((!(isset($context["display"]) ? $context["display"] : $this->getContext($context, "display")))) {
                    // line 12
                    echo "                ";
                    $context["display"] = $this->env->getExtension('security')->isGranted((isset($context["role"]) ? $context["role"] : $this->getContext($context, "role")));
                    // line 13
                    echo "            ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 14
            echo "
            ";
            // line 16
            echo "            ";
            $context["item_count"] = 0;
            // line 17
            echo "            ";
            if ((isset($context["display"]) ? $context["display"] : $this->getContext($context, "display"))) {
                // line 18
                echo "                ";
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "items"));
                foreach ($context['_seq'] as $context["_key"] => $context["admin"]) {
                    if (((isset($context["item_count"]) ? $context["item_count"] : $this->getContext($context, "item_count")) == 0)) {
                        // line 19
                        echo "                    ";
                        if (($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "hasroute", array(0 => "list"), "method") && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "isGranted", array(0 => "LIST"), "method"))) {
                            // line 20
                            echo "                        ";
                            $context["item_count"] = ((isset($context["item_count"]) ? $context["item_count"] : $this->getContext($context, "item_count")) + 1);
                            // line 21
                            echo "                    ";
                        }
                        // line 22
                        echo "                ";
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['admin'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 23
                echo "            ";
            }
            // line 24
            echo "
            ";
            // line 25
            if (((isset($context["display"]) ? $context["display"] : $this->getContext($context, "display")) && ((isset($context["item_count"]) ? $context["item_count"] : $this->getContext($context, "item_count")) > 0))) {
                // line 26
                echo "                ";
                if ((((isset($context["columnsCount"]) ? $context["columnsCount"] : $this->getContext($context, "columnsCount")) > 1) && (($this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "index0") % (isset($context["itemsPerColumn"]) ? $context["itemsPerColumn"] : $this->getContext($context, "itemsPerColumn"))) == 0))) {
                    // line 27
                    echo "                    ";
                    if ($this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "first")) {
                        // line 28
                        echo "                        <div class=\"row\">
                    ";
                    }
                    // line 30
                    echo "                    <div class=\"col-md-";
                    echo twig_escape_filter($this->env, twig_round((12 / (isset($context["columnsCount"]) ? $context["columnsCount"] : $this->getContext($context, "columnsCount")))), "html", null, true);
                    echo "\">
                    <ul class=\"dropdown-menu\">
                ";
                }
                // line 33
                echo "
                <li role=\"presentation\" class=\"dropdown-header\">";
                // line 34
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "label"), array(), $this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "label_catalogue")), "html", null, true);
                echo "</li>
                ";
                // line 35
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "items"));
                foreach ($context['_seq'] as $context["_key"] => $context["admin"]) {
                    // line 36
                    echo "                    ";
                    if (($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "hasroute", array(0 => "create"), "method") && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "isGranted", array(0 => "CREATE"), "method"))) {
                        // line 37
                        echo "                        <li role=\"presentation\">
                            <a role=\"menuitem\" tabindex=\"-1\" href=\"";
                        // line 38
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "generateUrl", array(0 => "create"), "method"), "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "label"), array(), $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "translationdomain")), "html", null, true);
                        echo "</a>
                        </li>
                    ";
                    }
                    // line 41
                    echo "                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['admin'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 42
                echo "
                ";
                // line 43
                if (((!$this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "last")) && (($this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "index") % (isset($context["itemsPerColumn"]) ? $context["itemsPerColumn"] : $this->getContext($context, "itemsPerColumn"))) != 0))) {
                    // line 44
                    echo "                    <li role=\"presentation\" class=\"divider\"></li>
                ";
                }
                // line 46
                echo "
            ";
                // line 47
                if ((($this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "length") > (isset($context["itemsPerColumn"]) ? $context["itemsPerColumn"] : $this->getContext($context, "itemsPerColumn"))) && (($this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "index") % (isset($context["itemsPerColumn"]) ? $context["itemsPerColumn"] : $this->getContext($context, "itemsPerColumn"))) == 0))) {
                    // line 48
                    echo "                </ul>
                </div>
            ";
                }
                // line 51
                echo "                ";
                if ((($this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "length") > (isset($context["itemsPerColumn"]) ? $context["itemsPerColumn"] : $this->getContext($context, "itemsPerColumn"))) && $this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "last"))) {
                    // line 52
                    echo "                    </div>
                ";
                }
                // line 54
                echo "            ";
            }
            // line 55
            echo "        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        echo "    </ul>
";
    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:Core:add_block.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  217 => 56,  203 => 55,  200 => 54,  196 => 52,  188 => 48,  183 => 46,  177 => 43,  143 => 33,  136 => 30,  129 => 27,  126 => 26,  124 => 25,  121 => 24,  118 => 23,  108 => 21,  96 => 18,  87 => 14,  71 => 11,  68 => 10,  36 => 6,  32 => 4,  27 => 13,  25 => 12,  20 => 1,  175 => 74,  168 => 41,  162 => 68,  156 => 64,  152 => 62,  144 => 59,  141 => 58,  134 => 55,  123 => 52,  120 => 51,  111 => 22,  101 => 42,  90 => 16,  81 => 33,  74 => 30,  43 => 18,  37 => 17,  29 => 3,  26 => 2,  911 => 264,  908 => 263,  905 => 262,  901 => 295,  897 => 293,  891 => 290,  888 => 289,  886 => 288,  880 => 285,  872 => 284,  869 => 283,  867 => 282,  864 => 281,  858 => 279,  856 => 278,  853 => 277,  847 => 275,  845 => 274,  842 => 273,  836 => 271,  834 => 270,  831 => 269,  825 => 267,  823 => 266,  820 => 265,  818 => 262,  815 => 261,  812 => 260,  808 => 254,  803 => 251,  795 => 246,  789 => 242,  787 => 241,  783 => 239,  777 => 237,  775 => 236,  771 => 234,  765 => 231,  762 => 230,  760 => 229,  757 => 228,  754 => 227,  751 => 226,  746 => 255,  743 => 226,  740 => 225,  735 => 296,  733 => 260,  728 => 257,  726 => 225,  723 => 224,  720 => 223,  715 => 298,  713 => 223,  710 => 222,  707 => 221,  702 => 214,  699 => 213,  695 => 212,  691 => 210,  685 => 209,  680 => 206,  674 => 205,  662 => 203,  659 => 202,  655 => 201,  648 => 200,  642 => 199,  639 => 198,  636 => 197,  633 => 196,  628 => 195,  626 => 194,  619 => 191,  615 => 190,  611 => 188,  609 => 187,  606 => 186,  603 => 185,  596 => 184,  593 => 183,  590 => 182,  587 => 181,  581 => 180,  578 => 179,  575 => 178,  572 => 176,  565 => 175,  562 => 174,  556 => 173,  553 => 172,  549 => 171,  546 => 170,  543 => 169,  540 => 168,  534 => 167,  530 => 165,  516 => 156,  510 => 154,  507 => 153,  504 => 152,  500 => 216,  497 => 213,  494 => 168,  492 => 167,  489 => 166,  486 => 152,  483 => 151,  477 => 217,  475 => 151,  471 => 149,  468 => 148,  460 => 137,  457 => 136,  449 => 130,  446 => 129,  438 => 123,  435 => 122,  431 => 119,  427 => 117,  421 => 115,  418 => 114,  415 => 113,  401 => 112,  395 => 110,  391 => 108,  385 => 106,  377 => 104,  375 => 103,  372 => 102,  369 => 101,  351 => 100,  348 => 99,  346 => 98,  343 => 97,  340 => 96,  337 => 95,  333 => 144,  329 => 142,  327 => 122,  323 => 120,  321 => 95,  310 => 86,  307 => 85,  304 => 84,  296 => 81,  291 => 79,  288 => 78,  282 => 76,  277 => 52,  268 => 50,  264 => 49,  257 => 45,  253 => 43,  247 => 42,  239 => 41,  235 => 39,  232 => 38,  227 => 35,  218 => 33,  214 => 32,  211 => 31,  208 => 30,  202 => 26,  199 => 25,  193 => 51,  186 => 47,  184 => 221,  181 => 220,  179 => 44,  174 => 42,  171 => 84,  169 => 78,  164 => 76,  160 => 38,  157 => 37,  154 => 36,  140 => 71,  132 => 28,  128 => 66,  122 => 64,  105 => 20,  102 => 19,  99 => 41,  93 => 17,  86 => 56,  82 => 54,  80 => 13,  77 => 12,  75 => 30,  72 => 29,  70 => 29,  65 => 23,  62 => 24,  60 => 21,  56 => 21,  54 => 18,  52 => 17,  50 => 16,  48 => 8,  46 => 19,  44 => 13,  40 => 11,  170 => 55,  165 => 52,  159 => 51,  153 => 49,  150 => 35,  146 => 34,  138 => 57,  135 => 69,  131 => 43,  125 => 65,  119 => 40,  116 => 50,  112 => 38,  109 => 46,  107 => 36,  103 => 34,  97 => 33,  91 => 58,  88 => 37,  84 => 29,  76 => 28,  73 => 27,  67 => 26,  64 => 25,  61 => 24,  58 => 22,  53 => 20,  51 => 9,  45 => 18,  42 => 7,  39 => 16,  34 => 16,  28 => 14,);
    }
}
