<?php

/* SonataAdminBundle:CRUD:base_acl.html.twig */
class __TwigTemplate_71471d8c1f7711d4d856a244cd288e5378c64a27c65a455bb5656075d8199049 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'actions' => array($this, 'block_actions'),
            'form' => array($this, 'block_form'),
            'formactions' => array($this, 'block_formactions'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate((isset($context["base_template"]) ? $context["base_template"] : $this->getContext($context, "base_template")));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 14
    public function block_actions($context, array $blocks = array())
    {
        // line 15
        echo "    <li>";
        $this->env->loadTemplate("SonataAdminBundle:Button:edit_button.html.twig")->display($context);
        echo "</li>
    <li>";
        // line 16
        $this->env->loadTemplate("SonataAdminBundle:Button:history_button.html.twig")->display($context);
        echo "</li>
    <li>";
        // line 17
        $this->env->loadTemplate("SonataAdminBundle:Button:show_button.html.twig")->display($context);
        echo "</li>
    <li>";
        // line 18
        $this->env->loadTemplate("SonataAdminBundle:Button:list_button.html.twig")->display($context);
        echo "</li>
";
    }

    // line 21
    public function block_form($context, array $blocks = array())
    {
        // line 22
        echo "    <form class=\"form-horizontal\"
              action=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "generateUrl", array(0 => "acl", 1 => array("id" => $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "id", array(0 => (isset($context["object"]) ? $context["object"] : $this->getContext($context, "object"))), "method"), "uniqid" => $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "uniqid"), "subclass" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "get", array(0 => "subclass"), "method"))), "method"), "html", null, true);
        echo "\" ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'enctype');
        echo "
              method=\"POST\"
              ";
        // line 25
        if ((!$this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "html5_validate"), "method"))) {
            echo "novalidate=\"novalidate\"";
        }
        // line 26
        echo "              >
        ";
        // line 27
        if ((twig_length_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "errors")) > 0)) {
            // line 28
            echo "            <div class=\"sonata-ba-form-error\">
                ";
            // line 29
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
            echo "
            </div>
        ";
        }
        // line 32
        echo "
        <table class=\"table\">
            <thead>
                <tr>
                    <th>";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("td_username", array(), "SonataAdminBundle"), "html", null, true);
        echo "</th>
                    ";
        // line 37
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["permissions"]) ? $context["permissions"] : $this->getContext($context, "permissions")));
        foreach ($context['_seq'] as $context["_key"] => $context["permission"]) {
            // line 38
            echo "                    <th>";
            echo twig_escape_filter($this->env, (isset($context["permission"]) ? $context["permission"] : $this->getContext($context, "permission")), "html", null, true);
            echo "</th>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['permission'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "                </tr>
            </thead>
            <tbody>
            ";
        // line 43
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["users"]) ? $context["users"] : $this->getContext($context, "users")));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 44
            echo "                <tr>
                    <td>";
            // line 45
            echo twig_escape_filter($this->env, (isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "html", null, true);
            echo "</td>
                    ";
            // line 46
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["permissions"]) ? $context["permissions"] : $this->getContext($context, "permissions")));
            foreach ($context['_seq'] as $context["_key"] => $context["permission"]) {
                // line 47
                echo "                    <td>";
                echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), ($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "id") . (isset($context["permission"]) ? $context["permission"] : $this->getContext($context, "permission"))), array(), "array"), 'widget');
                echo "</td>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['permission'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 49
            echo "                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "            </tbody>
        </table>

        ";
        // line 54
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'rest');
        echo "

        ";
        // line 56
        $this->displayBlock('formactions', $context, $blocks);
        // line 61
        echo "    </form>
";
    }

    // line 56
    public function block_formactions($context, array $blocks = array())
    {
        // line 57
        echo "            <div class=\"well well-small form-actions\">
                <input class=\"btn btn-primary\" type=\"submit\" name=\"btn_create_and_edit\" value=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("btn_update_acl", array(), "SonataAdminBundle"), "html", null, true);
        echo "\">
            </div>
        ";
    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:base_acl.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  713 => 213,  704 => 209,  702 => 208,  698 => 206,  685 => 204,  668 => 200,  665 => 199,  634 => 190,  612 => 187,  607 => 186,  604 => 185,  601 => 184,  595 => 180,  591 => 178,  589 => 177,  584 => 176,  567 => 174,  538 => 170,  532 => 168,  504 => 155,  497 => 133,  491 => 131,  482 => 128,  472 => 149,  466 => 147,  455 => 142,  452 => 141,  401 => 120,  392 => 117,  382 => 115,  359 => 106,  353 => 104,  345 => 101,  340 => 100,  330 => 96,  324 => 92,  286 => 80,  205 => 56,  178 => 45,  118 => 46,  321 => 152,  295 => 83,  274 => 77,  272 => 134,  242 => 113,  236 => 109,  216 => 100,  70 => 27,  1414 => 421,  1408 => 419,  1402 => 417,  1400 => 416,  1398 => 415,  1394 => 414,  1385 => 413,  1383 => 412,  1380 => 411,  1367 => 405,  1361 => 403,  1355 => 401,  1353 => 400,  1351 => 399,  1347 => 398,  1341 => 397,  1339 => 396,  1336 => 395,  1323 => 389,  1317 => 387,  1311 => 385,  1309 => 384,  1307 => 383,  1303 => 382,  1297 => 381,  1291 => 380,  1287 => 379,  1283 => 378,  1279 => 377,  1273 => 376,  1271 => 375,  1268 => 374,  1256 => 369,  1251 => 368,  1249 => 367,  1246 => 366,  1237 => 360,  1231 => 358,  1228 => 357,  1223 => 356,  1221 => 355,  1218 => 354,  1211 => 349,  1202 => 347,  1198 => 346,  1195 => 345,  1192 => 344,  1190 => 343,  1187 => 342,  1179 => 338,  1177 => 337,  1174 => 336,  1168 => 332,  1162 => 330,  1159 => 329,  1157 => 328,  1154 => 327,  1145 => 322,  1143 => 321,  1118 => 320,  1115 => 319,  1112 => 318,  1109 => 317,  1106 => 316,  1103 => 315,  1100 => 314,  1098 => 313,  1095 => 312,  1088 => 308,  1084 => 307,  1079 => 306,  1077 => 305,  1074 => 304,  1067 => 299,  1064 => 298,  1056 => 293,  1053 => 292,  1051 => 291,  1048 => 290,  1040 => 285,  1036 => 284,  1032 => 283,  1029 => 282,  1027 => 281,  1024 => 280,  1016 => 276,  1014 => 272,  1012 => 271,  1009 => 270,  1004 => 266,  982 => 261,  979 => 260,  976 => 259,  973 => 258,  970 => 257,  967 => 256,  964 => 255,  961 => 254,  958 => 253,  955 => 252,  952 => 251,  950 => 250,  947 => 249,  939 => 243,  936 => 242,  934 => 241,  931 => 240,  923 => 236,  920 => 235,  918 => 234,  915 => 233,  903 => 229,  900 => 228,  897 => 227,  894 => 226,  892 => 225,  889 => 224,  881 => 220,  878 => 219,  876 => 218,  873 => 217,  865 => 213,  862 => 212,  860 => 211,  857 => 210,  849 => 206,  846 => 205,  844 => 204,  841 => 203,  833 => 199,  830 => 198,  828 => 197,  825 => 196,  817 => 192,  814 => 191,  812 => 190,  809 => 189,  801 => 185,  798 => 184,  796 => 183,  793 => 182,  785 => 178,  783 => 177,  780 => 176,  772 => 172,  769 => 171,  767 => 170,  764 => 169,  756 => 165,  753 => 164,  751 => 163,  749 => 162,  746 => 161,  739 => 156,  729 => 155,  724 => 154,  721 => 153,  715 => 151,  712 => 150,  710 => 149,  707 => 210,  699 => 142,  697 => 141,  696 => 140,  695 => 205,  694 => 138,  689 => 137,  683 => 135,  680 => 202,  675 => 132,  666 => 126,  662 => 198,  658 => 124,  654 => 193,  649 => 122,  643 => 120,  638 => 118,  635 => 117,  619 => 113,  617 => 189,  614 => 111,  598 => 107,  596 => 106,  593 => 105,  576 => 101,  557 => 96,  555 => 95,  547 => 93,  529 => 167,  527 => 166,  515 => 160,  512 => 84,  509 => 157,  503 => 81,  501 => 154,  493 => 78,  478 => 74,  470 => 73,  467 => 72,  464 => 146,  456 => 68,  450 => 140,  442 => 62,  433 => 60,  428 => 136,  426 => 135,  405 => 49,  400 => 47,  390 => 43,  385 => 41,  377 => 37,  371 => 35,  366 => 33,  363 => 32,  350 => 26,  344 => 24,  335 => 21,  332 => 20,  316 => 16,  290 => 5,  276 => 395,  266 => 74,  263 => 365,  245 => 335,  207 => 269,  194 => 53,  76 => 28,  200 => 54,  58 => 23,  170 => 55,  551 => 184,  548 => 183,  546 => 172,  541 => 171,  537 => 178,  525 => 172,  520 => 170,  516 => 169,  513 => 168,  506 => 156,  502 => 164,  496 => 79,  489 => 157,  483 => 154,  479 => 127,  475 => 152,  462 => 146,  448 => 139,  443 => 137,  424 => 128,  421 => 127,  414 => 52,  403 => 48,  399 => 116,  391 => 113,  386 => 116,  375 => 114,  372 => 113,  354 => 102,  348 => 100,  346 => 99,  342 => 23,  325 => 93,  313 => 15,  308 => 13,  302 => 84,  296 => 82,  292 => 82,  255 => 353,  184 => 47,  155 => 53,  146 => 47,  126 => 55,  124 => 47,  188 => 48,  181 => 232,  161 => 202,  320 => 122,  317 => 89,  311 => 14,  288 => 81,  284 => 106,  279 => 78,  275 => 103,  256 => 96,  250 => 67,  237 => 70,  232 => 84,  222 => 297,  191 => 246,  153 => 49,  150 => 56,  110 => 42,  687 => 397,  678 => 133,  673 => 388,  671 => 383,  661 => 380,  656 => 378,  651 => 192,  647 => 374,  640 => 119,  636 => 366,  630 => 363,  626 => 362,  620 => 359,  610 => 352,  602 => 347,  592 => 340,  585 => 336,  578 => 332,  574 => 330,  572 => 327,  570 => 326,  564 => 99,  560 => 322,  550 => 173,  543 => 181,  535 => 169,  531 => 175,  524 => 165,  519 => 295,  511 => 158,  505 => 291,  499 => 163,  495 => 289,  490 => 77,  485 => 129,  481 => 284,  477 => 283,  465 => 276,  459 => 69,  454 => 271,  447 => 139,  439 => 261,  429 => 254,  425 => 253,  418 => 248,  416 => 242,  412 => 126,  408 => 50,  397 => 235,  395 => 118,  388 => 42,  380 => 223,  369 => 112,  356 => 105,  339 => 191,  334 => 98,  310 => 89,  297 => 166,  291 => 165,  282 => 161,  259 => 149,  244 => 65,  231 => 133,  226 => 131,  215 => 280,  186 => 47,  152 => 61,  114 => 111,  104 => 40,  358 => 139,  351 => 135,  347 => 102,  343 => 132,  338 => 130,  327 => 94,  323 => 125,  319 => 90,  315 => 150,  301 => 144,  299 => 8,  293 => 6,  289 => 140,  281 => 411,  277 => 136,  271 => 76,  265 => 130,  262 => 105,  260 => 70,  257 => 103,  251 => 101,  248 => 116,  239 => 97,  228 => 68,  225 => 58,  213 => 82,  211 => 81,  197 => 54,  174 => 42,  148 => 64,  134 => 55,  127 => 32,  270 => 157,  253 => 342,  233 => 62,  212 => 279,  210 => 270,  206 => 71,  202 => 266,  198 => 66,  192 => 88,  185 => 86,  180 => 66,  175 => 74,  172 => 51,  167 => 48,  165 => 52,  160 => 57,  137 => 46,  113 => 44,  100 => 40,  90 => 16,  81 => 32,  65 => 30,  129 => 27,  97 => 33,  84 => 29,  34 => 15,  53 => 22,  77 => 12,  20 => 1,  23 => 18,  480 => 75,  474 => 161,  469 => 158,  461 => 145,  457 => 153,  453 => 151,  444 => 138,  440 => 148,  437 => 61,  435 => 146,  430 => 130,  427 => 129,  423 => 134,  413 => 134,  409 => 132,  407 => 123,  402 => 236,  398 => 119,  393 => 114,  387 => 122,  384 => 121,  381 => 108,  379 => 119,  374 => 36,  368 => 34,  365 => 141,  362 => 110,  360 => 109,  355 => 27,  341 => 131,  337 => 99,  322 => 91,  314 => 99,  312 => 149,  309 => 88,  305 => 86,  298 => 91,  294 => 90,  285 => 3,  283 => 79,  278 => 410,  268 => 373,  264 => 2,  258 => 354,  252 => 80,  247 => 66,  241 => 77,  229 => 73,  220 => 57,  214 => 99,  177 => 43,  169 => 210,  140 => 51,  132 => 28,  128 => 47,  107 => 36,  61 => 28,  273 => 394,  269 => 75,  254 => 147,  243 => 327,  240 => 64,  238 => 312,  235 => 63,  230 => 61,  227 => 301,  224 => 103,  221 => 67,  219 => 101,  217 => 56,  208 => 124,  204 => 267,  179 => 44,  159 => 51,  143 => 33,  135 => 45,  119 => 40,  102 => 19,  71 => 32,  67 => 26,  63 => 25,  59 => 164,  38 => 18,  94 => 16,  89 => 33,  85 => 31,  75 => 29,  68 => 31,  56 => 23,  87 => 36,  21 => 11,  26 => 2,  93 => 17,  88 => 37,  78 => 34,  46 => 19,  27 => 14,  44 => 18,  31 => 15,  28 => 14,  201 => 65,  196 => 52,  183 => 46,  171 => 216,  166 => 209,  163 => 58,  158 => 75,  156 => 64,  151 => 188,  142 => 61,  138 => 46,  136 => 58,  121 => 24,  117 => 51,  105 => 20,  91 => 37,  62 => 24,  49 => 111,  24 => 13,  25 => 12,  19 => 11,  79 => 35,  72 => 28,  69 => 32,  47 => 22,  40 => 17,  37 => 17,  22 => 12,  246 => 99,  157 => 56,  145 => 54,  139 => 59,  131 => 43,  123 => 48,  120 => 46,  115 => 45,  111 => 43,  108 => 42,  101 => 40,  98 => 39,  96 => 18,  83 => 37,  74 => 30,  66 => 30,  55 => 25,  52 => 112,  50 => 21,  43 => 21,  41 => 18,  35 => 17,  32 => 4,  29 => 3,  209 => 96,  203 => 55,  199 => 265,  193 => 51,  189 => 240,  187 => 87,  182 => 85,  176 => 82,  173 => 42,  168 => 41,  164 => 203,  162 => 68,  154 => 36,  149 => 62,  147 => 52,  144 => 51,  141 => 58,  133 => 49,  130 => 57,  125 => 42,  122 => 45,  116 => 45,  112 => 38,  109 => 43,  106 => 104,  103 => 41,  99 => 41,  95 => 38,  92 => 38,  86 => 36,  82 => 36,  80 => 13,  73 => 27,  64 => 25,  60 => 22,  57 => 27,  54 => 26,  51 => 21,  48 => 8,  45 => 18,  42 => 17,  39 => 16,  36 => 16,  33 => 16,  30 => 15,);
    }
}
