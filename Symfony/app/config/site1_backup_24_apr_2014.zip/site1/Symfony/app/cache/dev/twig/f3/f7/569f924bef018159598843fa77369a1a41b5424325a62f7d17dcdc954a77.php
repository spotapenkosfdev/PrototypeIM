<?php

/* SonataAdminBundle:Block:block_admin_list.html.twig */
class __TwigTemplate_f3f7569f924bef018159598843fa77369a1a41b5424325a62f7d17dcdc954a77 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'block' => array($this, 'block_block'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute($this->getAttribute((isset($context["sonata_block"]) ? $context["sonata_block"] : $this->getContext($context, "sonata_block")), "templates"), "block_base"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 14
    public function block_block($context, array $blocks = array())
    {
        // line 15
        echo "    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["groups"]) ? $context["groups"] : $this->getContext($context, "groups")));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 16
            echo "        ";
            $context["display"] = (twig_test_empty($this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "roles")) || $this->env->getExtension('security')->isGranted("ROLE_SUPER_ADMIN"));
            // line 17
            echo "        ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "roles"));
            foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
                if ((!(isset($context["display"]) ? $context["display"] : $this->getContext($context, "display")))) {
                    // line 18
                    echo "            ";
                    $context["display"] = $this->env->getExtension('security')->isGranted((isset($context["role"]) ? $context["role"] : $this->getContext($context, "role")));
                    // line 19
                    echo "        ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 20
            echo "
        ";
            // line 21
            if ((isset($context["display"]) ? $context["display"] : $this->getContext($context, "display"))) {
                // line 22
                echo "            <div class=\"box\">
                <div class=\"box-header\">
                    <h3 class=\"box-title\">";
                // line 24
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "label"), array(), $this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "label_catalogue")), "html", null, true);
                echo "</h3>
                </div>
                <div class=\"box-body\">
                    <table class=\"table table-hover\">
                        <tbody>
                            ";
                // line 29
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "items"));
                foreach ($context['_seq'] as $context["_key"] => $context["admin"]) {
                    // line 30
                    echo "                                ";
                    if ((($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "hasroute", array(0 => "create"), "method") && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "isGranted", array(0 => "CREATE"), "method")) || ($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "hasroute", array(0 => "list"), "method") && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "isGranted", array(0 => "LIST"), "method")))) {
                        // line 31
                        echo "                                            <tr>
                                                <td class=\"sonata-ba-list-label\" width=\"40%\">
                                                    ";
                        // line 33
                        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "label"), array(), $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "translationdomain")), "html", null, true);
                        echo "
                                                </td>
                                                <td>
                                                    <div class=\"btn-group\">
                                                        ";
                        // line 37
                        if (($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "hasroute", array(0 => "create"), "method") && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "isGranted", array(0 => "CREATE"), "method"))) {
                            // line 38
                            echo "                                                            ";
                            if (twig_test_empty($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "subClasses"))) {
                                // line 39
                                echo "                                                                <a class=\"btn btn-link btn-flat\" href=\"";
                                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "generateUrl", array(0 => "create"), "method"), "html", null, true);
                                echo "\">
                                                                    <i class=\"fa fa-plus-circle\"></i>
                                                                    ";
                                // line 41
                                echo $this->env->getExtension('translator')->getTranslator()->trans("link_add", array(), "SonataAdminBundle");
                                // line 42
                                echo "                                                                </a>
                                                            ";
                            } else {
                                // line 44
                                echo "                                                                <a class=\"btn btn-link btn-flat dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                                                                    <i class=\"fa fa-plus-circle\"></i>
                                                                    ";
                                // line 46
                                echo $this->env->getExtension('translator')->getTranslator()->trans("link_add", array(), "SonataAdminBundle");
                                // line 47
                                echo "                                                                    <span class=\"caret\"></span>
                                                                </a>
                                                                <ul class=\"dropdown-menu\">
                                                                    ";
                                // line 50
                                $context['_parent'] = (array) $context;
                                $context['_seq'] = twig_ensure_traversable(twig_get_array_keys_filter($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "subclasses")));
                                foreach ($context['_seq'] as $context["_key"] => $context["subclass"]) {
                                    // line 51
                                    echo "                                                                        <li>
                                                                            <a href=\"";
                                    // line 52
                                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "generateUrl", array(0 => "create", 1 => array("subclass" => (isset($context["subclass"]) ? $context["subclass"] : $this->getContext($context, "subclass")))), "method"), "html", null, true);
                                    echo "\">";
                                    echo twig_escape_filter($this->env, (isset($context["subclass"]) ? $context["subclass"] : $this->getContext($context, "subclass")), "html", null, true);
                                    echo "</a>
                                                                        </li>
                                                                    ";
                                }
                                $_parent = $context['_parent'];
                                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['subclass'], $context['_parent'], $context['loop']);
                                $context = array_intersect_key($context, $_parent) + $_parent;
                                // line 55
                                echo "                                                                </ul>
                                                            ";
                            }
                            // line 57
                            echo "                                                        ";
                        }
                        // line 58
                        echo "                                                        ";
                        if (($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "hasroute", array(0 => "list"), "method") && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "isGranted", array(0 => "LIST"), "method"))) {
                            // line 59
                            echo "                                                            <a class=\"btn btn-link btn-flat\" href=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "generateUrl", array(0 => "list"), "method"), "html", null, true);
                            echo "\">
                                                                <i class=\"glyphicon glyphicon-list\"></i>
                                                                ";
                            // line 61
                            echo $this->env->getExtension('translator')->getTranslator()->trans("link_list", array(), "SonataAdminBundle");
                            // line 62
                            echo "</a>
                                                        ";
                        }
                        // line 64
                        echo "                                                    </div>
                                                </td>
                                            </tr>
                                ";
                    }
                    // line 68
                    echo "                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['admin'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 69
                echo "                        </tbody>
                    </table>
                </div>
            </div>
        ";
            }
            // line 74
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:Block:block_admin_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  175 => 74,  168 => 69,  162 => 68,  156 => 64,  152 => 62,  144 => 59,  141 => 58,  134 => 55,  123 => 52,  120 => 51,  111 => 47,  101 => 42,  90 => 38,  81 => 33,  74 => 30,  43 => 18,  37 => 17,  29 => 15,  26 => 14,  911 => 264,  908 => 263,  905 => 262,  901 => 295,  897 => 293,  891 => 290,  888 => 289,  886 => 288,  880 => 285,  872 => 284,  869 => 283,  867 => 282,  864 => 281,  858 => 279,  856 => 278,  853 => 277,  847 => 275,  845 => 274,  842 => 273,  836 => 271,  834 => 270,  831 => 269,  825 => 267,  823 => 266,  820 => 265,  818 => 262,  815 => 261,  812 => 260,  808 => 254,  803 => 251,  795 => 246,  789 => 242,  787 => 241,  783 => 239,  777 => 237,  775 => 236,  771 => 234,  765 => 231,  762 => 230,  760 => 229,  757 => 228,  754 => 227,  751 => 226,  746 => 255,  743 => 226,  740 => 225,  735 => 296,  733 => 260,  728 => 257,  726 => 225,  723 => 224,  720 => 223,  715 => 298,  713 => 223,  710 => 222,  707 => 221,  702 => 214,  699 => 213,  695 => 212,  691 => 210,  685 => 209,  680 => 206,  674 => 205,  662 => 203,  659 => 202,  655 => 201,  648 => 200,  642 => 199,  639 => 198,  636 => 197,  633 => 196,  628 => 195,  626 => 194,  619 => 191,  615 => 190,  611 => 188,  609 => 187,  606 => 186,  603 => 185,  596 => 184,  593 => 183,  590 => 182,  587 => 181,  581 => 180,  578 => 179,  575 => 178,  572 => 176,  565 => 175,  562 => 174,  556 => 173,  553 => 172,  549 => 171,  546 => 170,  543 => 169,  540 => 168,  534 => 167,  530 => 165,  516 => 156,  510 => 154,  507 => 153,  504 => 152,  500 => 216,  497 => 213,  494 => 168,  492 => 167,  489 => 166,  486 => 152,  483 => 151,  477 => 217,  475 => 151,  471 => 149,  468 => 148,  460 => 137,  457 => 136,  449 => 130,  446 => 129,  438 => 123,  435 => 122,  431 => 119,  427 => 117,  421 => 115,  418 => 114,  415 => 113,  401 => 112,  395 => 110,  391 => 108,  385 => 106,  377 => 104,  375 => 103,  372 => 102,  369 => 101,  351 => 100,  348 => 99,  346 => 98,  343 => 97,  340 => 96,  337 => 95,  333 => 144,  329 => 142,  327 => 122,  323 => 120,  321 => 95,  310 => 86,  307 => 85,  304 => 84,  296 => 81,  291 => 79,  288 => 78,  282 => 76,  277 => 52,  268 => 50,  264 => 49,  257 => 45,  253 => 43,  247 => 42,  239 => 41,  235 => 39,  232 => 38,  227 => 35,  218 => 33,  214 => 32,  211 => 31,  208 => 30,  202 => 26,  199 => 25,  193 => 23,  186 => 300,  184 => 221,  181 => 220,  179 => 148,  174 => 145,  171 => 84,  169 => 78,  164 => 76,  160 => 74,  157 => 73,  154 => 72,  140 => 71,  132 => 68,  128 => 66,  122 => 64,  105 => 44,  102 => 62,  99 => 41,  93 => 39,  86 => 56,  82 => 54,  80 => 38,  77 => 31,  75 => 30,  72 => 29,  70 => 29,  65 => 23,  62 => 24,  60 => 21,  56 => 21,  54 => 18,  52 => 17,  50 => 16,  48 => 15,  46 => 19,  44 => 13,  40 => 11,  170 => 55,  165 => 52,  159 => 51,  153 => 49,  150 => 61,  146 => 47,  138 => 57,  135 => 69,  131 => 43,  125 => 65,  119 => 40,  116 => 50,  112 => 38,  109 => 46,  107 => 36,  103 => 34,  97 => 33,  91 => 58,  88 => 37,  84 => 29,  76 => 28,  73 => 27,  67 => 26,  64 => 25,  61 => 24,  58 => 22,  53 => 20,  51 => 21,  45 => 18,  42 => 12,  39 => 16,  34 => 16,  28 => 14,);
    }
}
